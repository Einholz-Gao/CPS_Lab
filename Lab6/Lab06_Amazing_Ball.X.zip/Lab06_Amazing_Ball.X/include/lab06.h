#ifndef LAB06_H
#define	LAB06_H

// contains the loop code
void main_loop();

#endif	/* LAB06_H */
