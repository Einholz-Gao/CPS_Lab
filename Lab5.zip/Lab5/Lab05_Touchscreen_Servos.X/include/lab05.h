#ifndef LAB05_H
#define	LAB05_H

// contains the loop code
void main_loop();

#endif	/* LAB05_H */
